The input format is:
n x k

where:
- n represents the size of the array,
- x is the number to be searched,
- k is the repetition factor.

You can run the program after compiling it with gcc.