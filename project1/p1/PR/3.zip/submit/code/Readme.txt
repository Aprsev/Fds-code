To run the code , you need to add stdio.h and time.h to your "include" vault, which is here in default.

In your terminal:

Compile & Build : 
gcc -o main main.c

Run:
.\main

Expected output: 

For Assignment 1: random c and founded number pairs.
For Assignment 2: different running time depending on specific Ns and Vs.