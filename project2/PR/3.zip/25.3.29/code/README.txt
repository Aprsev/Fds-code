The code includes two independent source code wirttenn in C.
Make sure the gcc environment has been successfully installed.
 Run the following commands in Linux/macOS terminals or Windows (MinGW/Cygwin):

# Compile
gcc prjct2.c -o prjct2 -Wall

Note: -Wall enables compiler warnings (optional).
Then execute the genereted binaries and follow the input prompts

./prjct

Notice：If your notepad cannot display underscore symbols( _ ), you just need to go to "Edit" - "Font" in the notepad and change the font style to "Bold".