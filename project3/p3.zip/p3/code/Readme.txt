# Transportation Hub
## How to execute 
Use your complier to compile and run the "main.c" program.
## How to run the program
To run the program you simply need to input the graph information and test data.
Given sample:
1.
10 16 2
1 2 1
1 3 1
1 4 2
2 4 1
2 5 2
3 4 1
3 0 1
4 5 1
4 6 2
5 6 1
7 3 2
7 8 1
7 0 3
8 9 1
9 0 2
0 6 2
3
1 6
7 0
5 5

expected output will be
2 3 4 5
None
None

2.
12 21 2
0 1 1
0 2 1
0 3 2
1 3 1
1 4 2
2 3 1
2 5 1
3 4 1
3 5 2
3 6 1
4 5 1
4 7 2
5 6 1
5 8 2
6 7 1
6 8 1
7 8 1
7 9 2
8 9 1
9 10 1
10 11 1
3
0 10
7 11
2 8

expected output
2 3 5 6 8 9
9 10
5 6
