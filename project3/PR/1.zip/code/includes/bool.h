#pragma once

// Define a boolean type for C 
typedef enum Boolean { false, true } bool;