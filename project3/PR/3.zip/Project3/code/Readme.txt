1. Open this folder in your terminal
2. Use "gcc ./main.c -o main" to compile the source code
3. Use "./main" to run the program
4.Follow the instruction in the program, with input 1-2respectively test case1.txt-case2.txt

plus: you can run datagen.c in the same process to obtain random case2