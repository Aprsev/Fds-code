# Performance measurement(A+B)
## How to execute 
Use your complier to compile and run the "plus_m.c" program.
## How to run the program
My program has 3 inputs:
### Input1
The first input will begin with a notice "Please input the size and max of the number(split them with a space):" , then please input two numbers after that : the first is the size (n),the second is the max(V) and please split with a space.
### Input2
The second input is :"If you want to see the detail numbers , please enter number 1(or will skip it)!!!only use it when N is quite small:" ,please input 1 if you have any problem with the random array and the program will print the whole array for you , or else you can just input any other numbers to skip the step.

After the two steps the terminal will print the time cost of the 2 programs.